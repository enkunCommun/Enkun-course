alert("hiii ");


let username = prompt("Enter your password");
let password = prompt("Enter your password");

function sayUnlock(){
    do {
        if (username == "tenzin" && password == "2323"){
            alert("Welcome " + username);
        } else {
            alert("Sorry try again");
        }
    } while(let i < 50)
}


sayUnlock();